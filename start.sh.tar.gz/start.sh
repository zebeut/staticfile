#!/bin/sh
# 9080, 9088

echo start >> /tmp/boot.txt

home_dir=/root
work_dir=$home_dir/data
conf_dir=$work_dir/conf
prg_dir=$work_dir/program

# 目录建立
mkdir -v $work_dir
mkdir -v $prg_dir
mkdir -pv $home_dir/.config/qBittorrent
mkdir -v $home_dir/Downloads

# 下载相关文件
wget -O $work_dir/conf.tar.gz 'https://raw.githubusercontent.com/zebeut/staticfile/main/conf.tar.gz'
#wget --directory-prefix=$prg_dir 'https://github.com/caddyserver/caddy/releases/download/v2.4.3/caddy_2.4.3_linux_amd64.tar.gz'
wget --directory-prefix=$prg_dir 'https://downloads.rclone.org/v1.66.0/rclone-v1.66.0-linux-amd64.zip'

#wget --directory-prefix=$prg_dir 'https://files.pythonhosted.org/packages/d3/7f/c780b7471ba0ff4548967a9f7a8b0bfce222c3a496c3dfad0164172222b0/supervisor-4.2.2.tar.gz'

# 软件安装
apt install -y qbittorrent-nox
apt install -y supervisor
# apt install -y python3
# pip install supervisor

# 处理相关文件
cd $work_dir
tar -xvf conf.tar.gz

cd $prg_dir
#tar -xf caddy_2.4.3_linux_amd64.tar.gz
unzip rclone-v1.66.0-linux-amd64.zip
#cd $prg_dir
#tar -xvf supervisor-4.2.2.tar.gz
#cd supervisor-4.2.2
#python3 setup.py install

# 环境配置
cd $work_dir
ln -sv $conf_dir/qbittorrent/qBittorrent.conf $home_dir/.config/qBittorrent

ln -sv $conf_dir/supervisor_conf/config.d/p.conf /etc/supervisor/conf.d

# 启动supervisor
#cd $conf_dir/supervisor_conf
#supervisord -c supervisord.conf
supervisorctl reload

# 防火墙端口开放
ufw allow 9080
ufw allow 9088
